# Image Upload - MEAN

1. cd backend
2. \$ npm start
3. cd ../frontend
4. \$ npm start
